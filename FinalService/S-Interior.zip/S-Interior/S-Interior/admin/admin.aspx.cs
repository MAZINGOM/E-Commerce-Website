﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace S_Interior.admin
{
    public partial class sadmin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string suers= "";
            suers += "<div class='card'>";
            suers += "<div class='card-body'>";
            suers += "<div class='dash-widget-header'>";
            suers += "<span class='dash-widget-icon bg-primary'>";
            suers += "<i class='fe fe-users'></i>";
            suers += "</span>";
            suers += "<div class='dash-count'>";
            suers += "<i class='fa fa-arrow-up text-success'></i> 200%";
            suers += "</div>";
            suers += "</div>";
            suers += "<div class='dash-widget-info'>";
            suers += "<h3>168</h3>";
            suers += "<h6 class='text-muted'>Clients</h6>";
            suers += "<div class='progress progress-sm'>";
            suers += "<div class='progress-bar bg-primary w-50'></div>";
            suers += "</div>";
            suers += "</div>";
            suers += "</div>";
            suers += "</div>";
            userhm.InnerHtml = suers; 
        }
    }
}