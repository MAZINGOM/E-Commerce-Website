﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using S_Interior.FinalService;

namespace S_Interior
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        FunctionsClient sr = new FunctionsClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Login"] == null && Session["Email"] == null && Session["UserID"] == null)
            {
                Response.Redirect("login.aspx");
            }
            else
            {
                dynamic cartF = sr.listCart(Convert.ToInt16(Session["UserID"]));
                string display = "";
                string displayTotal = "";
                int num = 0;
                double total = 0;
                foreach (cartTable c in cartF)
                {
                    string smallCarts = "";
                    num = Convert.ToInt16(c.FurnitureNumber);
                    int totalInside = 0;
                    dynamic furnt = sr.listCartFuniture(Convert.ToInt16(c.FurnitureID));
                    foreach (FurnitureTable f in furnt)
                    {
                        smallCarts += "<tr>";
                        smallCarts += "<td class='product-name'>";
                        smallCarts +=f.Name+"<strong class='product-qty'> ×" + num+"</strong>";
                        smallCarts += "</td>";
                        smallCarts +="<td class='product-total'>";
                        smallCarts +="<span class='amount'>R"+Math.Round(f.Price*num,2)+"</span>";
                        smallCarts +="</td>";
                        smallCarts +="</tr>";
                        total += Convert.ToInt16(f.Price*num);
                    }
                    display += smallCarts;
                }

                // for Tatal html
                smallCartHtml.InnerHtml = display;
                double tot = total * (15.00/100);
                displayTotal += "<tr>";
                displayTotal += "<th>Cart Subtotal</th>";
                displayTotal += "<td>R"+ Math.Round(total+tot,2) + "</td>";
                displayTotal += "</tr>";
                displayTotal += "<tr>";
                displayTotal += "<th>Order Total</th>";
                displayTotal += "<td><strong>R" +Math.Round(total+tot,2)+"</strong>";
                displayTotal += "</td>";
                displayTotal += "</tr>";
               Totalmytml.InnerHtml = displayTotal;
            }
        }
    }
}